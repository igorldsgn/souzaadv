# Souza Advogado — Site

## Como publicar no GitHub Pages

1. Acesse https://github.com e crie uma conta (se ainda não tiver)
2. Clique em **"New repository"**
3. Nomeie como: `souza-advogado` (ou qualquer nome)
4. Deixe como **Public** e clique em **Create repository**
5. Clique em **"uploading an existing file"**
6. Arraste **todos os arquivos desta pasta** (index.html + pasta assets/)
7. Clique em **Commit changes**
8. Vá em **Settings → Pages**
9. Em "Source", selecione **main** e clique **Save**
10. Aguarde 1-2 minutos e acesse: `https://seu-usuario.github.io/souza-advogado`

## Personalizar

- Substitua o número de WhatsApp `5571999999999` pelo número real em `index.html`
- Troque o e-mail `contato@souzaadvogado.com.br` pelo e-mail real
- Atualize a OAB com o número de inscrição correto
